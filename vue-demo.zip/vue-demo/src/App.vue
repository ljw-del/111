<script setup>
import HelloWorld from './components/HelloWorld.vue'
import Home from './components/Home.vue';
</script>

<template>
  
  <HelloWorld msg="Vite + Vue" />
   <Home />
</template>

<!-- <style>
/* 全局布局调整 */
html, body {
  margin: 0;
  padding: 0;
  width: 100%;
  min-height: 100vh;
  overflow-x: hidden; /* 防止横向滚动 */
}

#app {
  width: 100%;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
  box-sizing: border-box;
}
</style> -->